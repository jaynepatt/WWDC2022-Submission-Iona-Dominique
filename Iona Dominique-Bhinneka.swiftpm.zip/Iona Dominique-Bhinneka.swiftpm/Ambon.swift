//
//  Ambon.swift
//  Bhinneka
//
//  Created by id on 18/04/22.
//

import SwiftUI
import Foundation
import AVFoundation

var musik: AVAudioPlayer!

struct AmbonView: View {
    @State private var showPopUp = false
    @State var scale: CGFloat = 1
    var body: some View {
        VStack {
            
        Text("Welcome to Ambon")
            .font(Font.system(size: 46, weight: .bold))
            .multilineTextAlignment(.center)
            .foregroundStyle(

                        LinearGradient(
                            colors: [.red, .blue, .green, .yellow],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
        }.onAppear(perform: self.playMusik)
            .onDisappear(perform: self.stopMusik)
        ZStack {
            Image("Maluku")
                   .resizable()
                   .scaledToFill()
                   .edgesIgnoringSafeArea(.all)
                  
            Button(action: {self.showPopUp = true}, label: {Image("maluku_man")
                .offset(x: -5, y: -10)
                .scaleEffect(scale)
               .onAppear {
                   let baseAnimation = Animation.easeInOut(duration: 1)
                   let repeated = baseAnimation.repeatForever(autoreverses: true)

                   withAnimation(repeated) {
                       scale = 0.5}}
                   
    
          
                
                if $showPopUp.wrappedValue {
                                    ZStack {
                                                                Color.white
                                                                VStack {
                                                                    Text("Origin of Ambon").foregroundColor(.blue)
                                                                        .bold()
                                                                    Spacer()
                                                                    Text("The term Ambon (or Ambong in the local language) itself according to local residents comes from the word 'ombong' which means 'dew'. This refers to the peaks on the island which is often covered in thick dew. ").multilineTextAlignment(.center)
                                                                        Spacer()
                                                                    Button(action: {
                                                                        self.showPopUp = false
                                                                    }, label: {
                                                                        Text("Close")
                                                                    })
                                                                }.padding()
                                                            }
                                                            .frame(width: 300, height: 270)
                                                            .cornerRadius(20).shadow(radius: 20)
                    
                  
                                                        
}}
                
           
        
       ) }}
}

extension AmbonView {
    func playMusik() {
        if let musicURL = Bundle.main.url(forResource: "Rasa Sayange_Maluku", withExtension: "mp3") {
            if let audioPlayer = try? AVAudioPlayer(contentsOf: musicURL) {
                musik = audioPlayer
                musik.numberOfLoops = -1
                musik.play()
                playMusik()
                
                
                    
                    
                }
            }
        }
    func stopMusik() {
        musik.stop()
                
    }

}

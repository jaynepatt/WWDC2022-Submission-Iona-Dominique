//
//  Bandung.swift
//  Bhinneka
//
//  Created by id on 18/04/22.
//

import SwiftUI
import Foundation
import AVFoundation


var lagu: AVAudioPlayer!
var animation: Animation {
    Animation.easeOut
}

struct BandungView: View {
    @State var scale: CGFloat = 1
    @State private var showPopUp = false
    var body: some View {
        VStack {
          
        Text("Welcome to Bandung")
            .font(Font.system(size: 46, weight: .bold))
            .multilineTextAlignment(.center)
            .foregroundStyle(

                        LinearGradient(
                            colors: [.red, .blue, .green, .yellow],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
        }.onAppear(perform: self.playLagu)
            .onDisappear(perform: self.stopLagu)
        
        
        ZStack
        {
            Image("Bandung")
                  .resizable()
                  .scaledToFill()
                  .edgesIgnoringSafeArea(.all)
            Image ("Angklung").position(x:500 , y:200 )
            
        
            Button(action: {self.showPopUp = true}, label: {Image ("BandungCouple").position(x:300 , y:500 )
                    .scaleEffect(scale)
                                .onAppear {
                                    let baseAnimation = Animation.easeInOut(duration: 1)
                                    let repeated = baseAnimation.repeatForever(autoreverses: true)

                                    withAnimation(repeated) {
                                        scale = 0.5}}
                
      
            
          
            
            
                   if $showPopUp.wrappedValue {
                       ZStack {
                           Color.white
                           VStack {
                               Text("Angklung").foregroundColor(.blue)
                                   .bold()
                               Spacer()
                               Text("Angklung is one of Indonesia's traditional musical instruments made of bamboo. It comes from West Java which has begun to be known by the world community. ").multilineTextAlignment(.center)
                                   Spacer()
                               Button(action: {
                                   self.showPopUp = false
                               }, label: {
                                   Text("Close")
                               })
                           }.padding()
                       }
                       .frame(width: 300, height: 270)
                       .cornerRadius(20).shadow(radius: 20)
                   
                   }
                     
                   
          
    
                   }
    )}
            }
    }

    extension BandungView {
        func playLagu() {
            if let musicURL = Bundle.main.url(forResource: "Musik_Bandung-2", withExtension: "mp3") {
                if let audioPlayer = try? AVAudioPlayer(contentsOf: musicURL) {
                    lagu = audioPlayer
                    lagu.numberOfLoops = -1
                    lagu.play()
                    playLagu()
                }
            }
        }
    
    func stopLagu() {
        lagu.stop()
                
    }

    }


                   

                    

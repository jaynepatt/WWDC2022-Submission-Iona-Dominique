//
//  CityDetailsView.swift
//  Bhinneka
//
//  Created by id on 18/04/22.
//

import SwiftUI
import MapKit

struct CityDetailsView: View {
    let place: Place
  
    var body: some View {
        SwiftUI.VStack(spacing: 20) {
            Text(place.title).font(.title)
            Text(place.coordinate.description)
                .font(.title2)
                .navigationTitle(place.title)
        }
        
        VStack() {
            List {
             switch place.title {
             case "Bali":
                 Text("Fun Facts about Bali").font(.headline).bold()
                         Text ("Also Known As : Pulau Dewata")
                 Text ("Bali is a very beautiful island with a long coastline of about 633.35 km. On the island of Bali there are volcanoes, rivers, and lakes. The existence of volcanoes provides soil fertility for agriculture. The volcanoes on the island of Bali are Mount Batur and Mount Agung.")
                 Text ("Most of the Balinese population is Hindu. In almost every corner of the area there are temples of worship, both large temples that are used as a place for joint ceremonies and small temples in every house. Therefore, apart from being known as the Island of the Gods, Bali is also known as the Island of a Thousand Temples. Strong religious rituals influence almost every element and movement of Balinese life. This makes Bali not only has beautiful scenery but also a unique, exotic, and well-maintained culture.")
                 NavigationLink(destination: BaliView()) {
                     Text("Let's Go to Bali!")
                 }
             case "Bandung":
                 Text("Fun Facts about Bandung").font(.headline).bold()
                 Text ("Also Known As : Bandoeng Parijs van Java")
                 Text ("Bandung city is the capital city of West Java province. This city was known in ancient times as Parijs van Java (Dutch) or 'Paris of Java'. This city is geographically located in the middle of the province of West Java, thus, as the provincial capital, Bandung has a strategic value to the surrounding areas. Because it is located in the highlands, Bandung is known as a place with cool air. This makes Bandung as a tourist destination.")
                 NavigationLink(destination: BandungView()) {
                     Text("Let's Go to Bandung!")
                
                 
                 
                     
                 }
             case "Ambon":
                 Text("Fun Facts about Ambon").font(.headline).bold()
                 Text("Also Known As : Ambon Manise")
                 Text ("Ambon is the capital of Maluku Province. In the past, Ambon was known as the world's best spice-producing area. Until now still. In addition to producing spices, Ambon is also known for its natural beauty which is so stunning for anyone who visits it.")
                 Text ("Ambon City is located in a flat area, surrounded by beautiful Ambon Bay, backed by lush green mountains and overlooking clear waters and coral gardens of colorful and diverse species.")
                 Text ("Ambon city is also known as 'Ambon Manise' which means Ambon is sweet or beautiful. This name is due to the charming natural beauty of Ambon and the friendliness of the people here, also known as the tropical island of Indonesia.")
                 NavigationLink(destination: AmbonView()) {
                     Text("Let's Go to Ambon!")
                 }
             case "Raja Ampat":
                 Text("Fun Facts about Raja Ampat").font(.headline).bold()
                 Text("Also Known As : The Last Paradiso")
                 Text ("Raja Ampat is a district in West Papua Province. This district has four large islands, namely Waigeo, Batanta, Salawati, and Misool islands. In addition, there are also 1,847 small islands in Raja Ampat.")
                 Text ("The name Raja Ampat comes from a local legend. It used to be believed there was a woman who found seven eggs. Four of the eggs hatched and became the ruling king of the four big islands. While the other three hatched into stone, one became a woman, and the other became a supernatural being.")
                 NavigationLink(destination: RajaAmpatView()) {
                     Text("Let's Go to Raja Ampat!")
                 }
             default:
                 Text("Fun Facts about Bandung").font(.headline).bold()
                 Text ("Also Known As : Bandoeng Parijs van Java")
                 Text ("Bandung city is the capital city of West Java province. This city was known in ancient times as Parijs van Java (Dutch) or 'Paris of Java'. This city is geographically located in the middle of the province of West Java, thus, as the provincial capital, Bandung has a strategic value to the surrounding areas. Because it is located in the highlands, Bandung is known as a place with cool air. This makes Bandung as a tourist destination.")
                 NavigationLink(destination: BandungView()) {
                     Text("Let's Go to Bandung!")
                 }
             }
            }
        }
    }
}
    
extension CLLocationCoordinate2D: CustomStringConvertible {
  public var description: String {
    "\(latitude);\(longitude)"
  }
}

struct CityDetailsView_Previews: PreviewProvider {
  static var previews: some View {
      CityDetailsView(place: Place(title: "Bandung", coordinate: CLLocationCoordinate2D(latitude: 0, longitude: 0)))
  }
}


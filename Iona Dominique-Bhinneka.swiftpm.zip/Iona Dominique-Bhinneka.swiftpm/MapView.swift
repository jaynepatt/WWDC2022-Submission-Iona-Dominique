import SwiftUI
import CoreLocation
import MapKit



struct MapView: View {
    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: -6.412707, longitude: 111.719122), span: MKCoordinateSpan(latitudeDelta: 40, longitudeDelta: 40))
    
    let placeArray: [Place] = [
        Place(title: "Bali", coordinate: CLLocationCoordinate2D(latitude: -8.409518, longitude: 115.188919)),
        Place(title: "Bandung", coordinate: CLLocationCoordinate2D(latitude: -6.905977, longitude: 107.613144)),
        Place(title: "Ambon", coordinate: CLLocationCoordinate2D(latitude: -3.654703, longitude: 128.190643)),
        Place(title: "Raja Ampat", coordinate: CLLocationCoordinate2D(latitude: -1.032047, longitude: 130.505218))
        ]
    
    var body: some View {
        Map(coordinateRegion: $region, annotationItems: placeArray) { annotation in

            MapAnnotation(coordinate: annotation.coordinate) {
                
                NavigationLink {
                    CityDetailsView(place: annotation)
                } label: {

                AnnotationView(title: annotation.title)
                }}
        }
    }
}

struct AnnotationView: View {
    
    let title: String
    @State private var showPlaceName = false
    
    var body: some View {
        VStack(spacing: 0) {
                Text(title)
                    .font(.callout)
                    .padding(5)
                    .background(Color(uiColor: .white))
                    .cornerRadius(10)
                    .foregroundColor(Color(uiColor: .black))
            
        
            Image(systemName: "mappin.circle.fill")
                .font(.title)
                .foregroundColor(.red)
            
            Image(systemName: "arrowtriangle.down.fill")
                .font(.caption)
                .foregroundColor(.red)
                .offset(x: 0, y: -5)
        
        
            
        }
        
    }
}

struct Place: Identifiable {
    let id = UUID()
    var title: String
    var coordinate: CLLocationCoordinate2D
}


   


//
//  Raja Ampat.swift
//  Bhinneka
//
//  Created by id on 18/04/22.
//

import SwiftUI
import Foundation
import AVFoundation

var Music: AVAudioPlayer!


struct RajaAmpatView: View {
    @State var scale: CGFloat = 1
    @State private var showPopUp = false
    var body: some View {
        VStack {
            
        Text("Welcome to Raja Ampat")
            .font(Font.system(size: 46, weight: .bold))
            .multilineTextAlignment(.center)
            .foregroundStyle(

                        LinearGradient(
                            colors: [.red, .blue, .green, .yellow],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
          
        }.onAppear(perform: self.playMusic)
    .onDisappear(perform: self.stopMusic)
        
        
        ZStack {
            Image("Papua")
                 .resizable()
                 .scaledToFill()
                 .edgesIgnoringSafeArea(.all)
            
            
            Button(action: {self.showPopUp = true}, label: {   Image("papua_couple")
                .offset(x: -5, y: -10)
                .scaleEffect(scale)
                .onAppear {
                    let baseAnimation = Animation.easeInOut(duration: 1)
                    let repeated = baseAnimation.repeatForever(autoreverses: true)

                    withAnimation(repeated) {
                        scale = 0.5}}
                
          if $showPopUp.wrappedValue {
                              ZStack {
                                                          Color.white
                                                          VStack {
                                                              Text("Unique Sand Phenomenon").foregroundColor(.blue)
                                                                  .bold()
                                                              Spacer()
                                                              Text("The phenomenon of sand arises in the Sembilan islands, Raja Ampat is somewhat unique. The reason is because the sand arises in the middle of the sea, not at the beach. ").multilineTextAlignment(.center)
                                                                  Spacer()
                                                              Button(action: {
                                                                  self.showPopUp = false
                                                              }, label: {
                                                                  Text("Close")
                                                              })
                                                          }.padding()
                                                      }
                                                      .frame(width: 300, height: 270)
                                                      .cornerRadius(20).shadow(radius: 20)
        
        }}
           
            )}}}

extension RajaAmpatView {
    func playMusic() {
        if let musicURL = Bundle.main.url(forResource: "Sajojo_Papua-2", withExtension: "mp3") {
            if let audioPlayer = try? AVAudioPlayer(contentsOf: musicURL) {
                music = audioPlayer
                music.numberOfLoops = -1
                music.play()
                playMusic()
                
                
               
                    
                    
                    
                    
                }
            }
        }
    func stopMusic() {
        music.stop()
                
    }


}

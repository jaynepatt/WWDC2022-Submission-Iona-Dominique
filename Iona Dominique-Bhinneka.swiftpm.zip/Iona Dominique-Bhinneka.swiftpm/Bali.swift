//
//  Bali.swift
//  Bhinneka
//
//  Created by id on 15/04/22.
//
import SwiftUI
import Foundation
import AVFoundation

var music: AVAudioPlayer!
struct BaliView: View {
    @State var scale: CGFloat = 1
    @State private var showPopUp = false
    var body: some View {

        
        VStack {
          
            Text("Welcome to Bali")
                .font(Font.system(size: 46, weight: .bold))
                .multilineTextAlignment(.center)
                
                .foregroundStyle(

                            LinearGradient(
                                colors: [.red, .blue, .green, .yellow],
                                startPoint: .leading,
                                endPoint: .trailing
                                
                                  
                            )
                        )
        }.onAppear(perform: self.playMusic)
        .onDisappear(perform: self.stopMusic)
        
        ZStack {
            Image("Bali")
                 .resizable()
                 .scaledToFill()
                 .edgesIgnoringSafeArea(.all)
            
            
            
            Button(action: {self.showPopUp = true}, label: {Image("Sekar")
                .offset(x: -5, y: -10)
                .scaleEffect(scale)
                            .onAppear {
                                let baseAnimation = Animation.easeInOut(duration: 1)
                                let repeated = baseAnimation.repeatForever(autoreverses: true)

                                withAnimation(repeated) {
                                    scale = 0.5}}
                                  
                            if $showPopUp.wrappedValue {
                                                ZStack {
                                                                            Color.white
                                                                            VStack {
                                                                                Text("Pura Ulun Danu Beratan").foregroundColor(.blue)
                                                                                    .bold()
                                                                                Spacer()
                                                                                Text("Ulun Danu Beratan Temple is a very unique temple because it's located in the middle of a lake. When the lake water rises, the Temple will be seen floating on the surface of the lake water. ").multilineTextAlignment(.center)
                                                                                    Spacer()
                                                                                Button(action: {
                                                                                    self.showPopUp = false
                                                                                }, label: {
                                                                                    Text("Close")
                                                                                })
                                                                            }.padding()
                                                                        }
                                                                        .frame(width: 300, height: 270)
                                                                        .cornerRadius(20).shadow(radius: 20)
                                                                    
            }}
                )   }
                                                             
           
        }}
           
        



    
extension BaliView {
    func playMusic() {
        if let musicURL = Bundle.main.url(forResource: "Gamelan Bali-2", withExtension: "mp3") {
            if let audioPlayer = try? AVAudioPlayer(contentsOf: musicURL) {
                music = audioPlayer
                music.numberOfLoops = -1
                music.play()
                playMusic()
                
                
               
                    
                    
                    
                    
                }
            }
        }
    func stopMusic() {
        music.stop()
                
    }

}

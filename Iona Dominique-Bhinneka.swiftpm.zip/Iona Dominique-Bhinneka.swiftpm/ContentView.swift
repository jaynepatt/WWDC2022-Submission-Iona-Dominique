import SwiftUI


struct ContentView : View {
    @State var scale: CGFloat = 1
    @State var numberOfShakes: CGFloat = 0
    @State private var showPopUp = false
    
    var body: some View {
        NavigationView {
        
            
           
            VStack {
            
                
                Text("Welcome to Bhinneka!")
                    .font(Font.system(size: 46, weight: .bold))
                    .multilineTextAlignment(.center)
                        .foregroundStyle(

                            LinearGradient(
                                colors: [.red, .blue, .green, .yellow],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                Button(action: {self.showPopUp = true}, label: { Image("Garuda")
                    .resizable()
                    .scaledToFit()})
                
                if $showPopUp.wrappedValue {
                    ZStack {
                        Color.white
                        VStack {
                            Text("Garuda").foregroundColor(.blue)
                                .bold()
                            Spacer()
                            Text("Garuda Pancasila symbolizes the unity and integrity of the Indonesian nation. This can be seen from the claws of the Garuda bird that holds the Indonesian motto, namely 'Bhinneka Tunggal Ika'.").multilineTextAlignment(.center)
                                Spacer()
                            Button(action: {
                                self.showPopUp = false
                            }, label: {
                                Text("Close")
                            })
                        }.padding()
                    }
                    .frame(width: 300, height: 270)
                    .cornerRadius(20).shadow(radius: 20)
                }
                
                Text ("Bhinneka is taken from Indonesia's national motto 'Bhinneka Tunggal Ika' which means unity in diversity. ")
                    .font(.system(size:20))
                    .multilineTextAlignment(.center)
                    .padding(10)
                    .background(RoundedRectangle(cornerRadius: 20)
                    .fill(.yellow))
                    .foregroundColor(.black)
                    .font(.title)
                    .frame(width:300)
            }
            
            VStack {
                
  
                VStack {
                
                
                Text (" Let's explore Indonesia with us! Click the explore button to start your journey !")
                    .font(.system(size:30))
                    .font(.headline).bold()
                    .multilineTextAlignment(.center)
                    .padding(10)
                    .background(RoundedRectangle(cornerRadius: 20)
                    .fill(.yellow))
                    .foregroundColor(.black)
                    .font(.title)
                    .frame(width:600)
                
                NavigationLink(destination: SecondView()) {
                Image("Bhinneka")
                    .resizable()
                    .scaledToFit()
                    .frame(alignment:.bottom)
                    
                    
                }
                    VStack{
                    NavigationLink(destination: SecondView()) {
                        Text("Explore!")
                            
                            .font(Font.system(size: 40, weight: .bold))
                            .multilineTextAlignment(.center)
                            .padding(10)
                            .background(RoundedRectangle(cornerRadius: 30)
                            .fill(.black))
                            .overlay {
                                LinearGradient(
                                    colors: [.red, .white],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                                .mask(
                                    Text("Explore!")
                                        .font(Font.system(size: 40, weight: .bold))
                                        .multilineTextAlignment(.center)

    
                                          
                                            
                                    )
                                
                            
                        }
                        }
                               
                    }
                        
                   
                }}
          }
        }
    }


    
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




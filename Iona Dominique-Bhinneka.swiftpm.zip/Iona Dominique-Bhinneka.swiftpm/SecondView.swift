//
//  File.swift
//  Bhinneka
//
//  Created by id on 04/04/22.
//

import SwiftUI


struct SecondView: View {
    var body: some View {
        VStack {
                        
            Spacer()
            Spacer()
            Spacer()
            Spacer()
            Spacer()
            Spacer()
            Spacer()
            Spacer()
        
           
          

            
            
        Text("Spot Indonesia!")
            .font(Font.system(size: 46, weight: .bold))
            .multilineTextAlignment(.center)
            .foregroundStyle(

                        LinearGradient(
                            colors: [.red, .blue, .green, .yellow],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
        
          
            
      MapView()
                 .frame(height: 1100)
            
         }
                
        }

}
struct SecondView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }

}
